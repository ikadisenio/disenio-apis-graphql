export const empleados=[
    {
        _id:1,
        nombre:'Mauricio Chiliquinga',
        sueldo:1000
    },
    {
        _id:2,
        nombre:'Gabriela Andrade',
        sueldo:1400
    },
    {
        _id:3,
        nombre:'Kamila Chiliquinga',
        sueldo:1000
    }
]

export const departamentos=[
    {
        _id:1,
        nombre:'Sistemas'
    },
    {
        _id:2,
        nombre:'Contabilidad'
    }
]