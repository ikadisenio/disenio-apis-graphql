// models/Departamento.js
const mongoose = require('mongoose');

const departamentoSchema = new mongoose.Schema({
  nombre: String,
  slogan: String
});

module.exports = mongoose.model('Departamento', departamentoSchema);
