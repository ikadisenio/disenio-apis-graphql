const Empleado= require('./models/empleado');
const Departamento = require('./models/departamento');

export const resolvers={
    Query:{
        
        empleados: async () => {
            return await Empleado.find();
        },
        departamentos: async () => {
            return await Departamento.find();
        },

        saludar(root,{name},context){
            console.log(context);
            return `Hola ${name}!`;
        },
    },

    Mutation:{
        
        createEmpleado: async (_, { input }) => {
            const nuevo = new Empleado(input);
            const guardado = await nuevo.save();
            return guardado;
        },

    
        createDepartmento: async (_, { input }) => {
            const nuevo = new Departamento(input);
            const guardado = await nuevo.save();
            return guardado;
        }
    }

}