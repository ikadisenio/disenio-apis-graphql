import express from "express"
const expressGraphqlHTTP = require('express-graphql');
const schema = require('./schema.js');
require('./database.js');

const app=express();
app.get('/',(req,res)=>{res.json({
    message:'GRAPHQL Empleados'
})});

app.use('/graphql',expressGraphqlHTTP.graphqlHTTP({
    graphiql:true,
    schema:schema
}

));
const server= app.listen('3000');
console.log('Server corriendo en el puerto',3000);
module.exports=server;